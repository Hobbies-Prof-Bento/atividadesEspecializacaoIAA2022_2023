#!/bin/bash
convert -delay 50 -loop 0 ../animation/output_*.jpg animation.gif
